/* Allegro datafile object indexes, produced by grabber v4.2.0, MSVC.s */
/* Datafile: d:\...Cursos UDEMY\Curso 03 - Curso de VideoJuego PacMan en C++\App\recursos.dat */
/* Date: Thu Mar 28 20:43:01 2019 */
/* Do not hand edit! */

#define arial20                          0        /* FONT */
#define arialbd                          1        /* FONT */

